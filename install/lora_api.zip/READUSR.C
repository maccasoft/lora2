/*

                      LoraBBS (DOS / OS2) Ver. 2.33

    Copyright (c) 1989, 1990, 1991, 1992, 1993 by Marco Maccaferri.
                          All rights reserved.


                          Source code examples
                       User record read routines


  You may use this structures at your own risk. The author cannot guarantee
  that this structures are maintained in all future versions of the program.
  You can freely (and you are encouraged on that) distribute this file
  without limitations.

  You can contact the autor at one of the following address:

  Marco Maccaferri
  BBS: 39-51-6331730 (2:332/402)

*/
#include <stdio.h>
#include <io.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>

#include "lora.h"
#include "crc32.h"

#define MAX_INDEX   500

void read_user_record (name)
char *name;
{
   int fd, fflag, m, i, posit;
   long crc;
   struct _usr usr;
   struct _usridx usridx[MAX_INDEX];

   crc = 0xFFFFFFFFL;
   for (i=0; i < strlen(name); i++)
      crc = Z_32UpdateCRC (((unsigned short) name[i]), crc);

   fd = open ("USERS.BBS", O_RDWR|O_BINARY);

   fflag = 0;
   posit = 0;

   do {
      i = read(fd,(char *)&usridx,sizeof(struct _usridx) * MAX_INDEX);
      m = i / sizeof (struct _usridx);

      for (i=0; i < m; i++)
         if (usridx[i].id == crc)
         {
            posit += i;
            fflag = 1;
            break;
         }

      if (!fflag)
         posit += m;
   } while (m == MAX_INDEX && !fflag);

   close (fd);

   fd = open ("USERS.BBS", O_RDWR|O_BINARY);

   lseek (fd, (long)posit * sizeof (struct _usr), SEEK_SET);
   read(fd, (char *)&usr, sizeof(struct _usr));

   close(fd);
}

