/*

                      LoraBBS (DOS / OS2) Ver. 2.33

    Copyright (c) 1989, 1990, 1991, 1992, 1993 by Marco Maccaferri.
                          All rights reserved.


                          Source code examples
                     System record read reoutines


  You may use this structures at your own risk. The author cannot guarantee
  that this structures are maintained in all future versions of the program.
  You can freely (and you are encouraged on that) distribute this file
  without limitations.

  You can contact the autor at one of the following address:

  Marco Maccaferri
  BBS: 39-51-6331730 (2:332/402)

*/
#include <stdio.h>
#include <io.h>
#include <time.h>
#include <fcntl.h>

#include "lora.h"

#define MSG_AREAS   200

int read_system(s, type)
int s, type;
{
   int fd, nsys, i;
   struct _sys_idx sysidx[MSG_AREAS];
   struct _sys sys;

   if (type == 1)
   {
      fd = open("SYSMSG.IDX", O_RDONLY|O_BINARY);
      if (fd == -1)
         return (0);
      nsys = read(fd, (char *)&sysidx, sizeof(struct _sys_idx) * MSG_AREAS);
      nsys /= sizeof (struct _sys_idx);
      close(fd);
   }
   else if (type == 2)
   {
      fd = open("SYSFILE.IDX", O_RDONLY|O_BINARY);
      if (fd == -1)
         return (0);
      nsys = read(fd, (char *)&sysidx, sizeof(struct _sys_idx) * MSG_AREAS);
      nsys /= sizeof (struct _sys_idx);
      close(fd);
   }

   for (i=0; i < nsys; i++)
   {
      if (sysidx[i].area == s)
         break;
   }

   if (i == nsys)
      return (0);

   if (type == 1)
   {
      fd = open("SYSMSG.DAT", O_RDONLY|O_BINARY);
      if (fd == -1)
         return (0);
      lseek (fd, (long)i * SIZEOF_MSGAREA, SEEK_SET);
      read(fd, (char *)&sys.msg_name, SIZEOF_MSGAREA);
      close(fd);
   }
   else if (type == 2)
   {
      fd = open("SYSFILE.DAT", O_RDONLY|O_BINARY);
      if (fd == -1)
         return (0);
      lseek (fd, (long)i * SIZEOF_FILEAREA, SEEK_SET);
      read(fd, (char *)&sys.file_name, SIZEOF_FILEAREA);
      close(fd);
   }

   return (1);
}

