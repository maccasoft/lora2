/*

                      LoraBBS (DOS / OS2) Ver. 2.33

    Copyright (c) 1989, 1990, 1991, 1992, 1993 by Marco Maccaferri.
                          All rights reserved.


                          Source code examples
                          Send on-line message


  You may use this structures at your own risk. The author cannot guarantee
  that this structures are maintained in all future versions of the program.
  You can freely (and you are encouraged on that) distribute this file
  without limitations.

  You can contact the autor at one of the following address:

  Marco Maccaferri
  BBS: 39-51-6331730 (2:332/402)

*/
#include <stdio.h>
#include <string.h>

#include "lora.h"

void send_online_message(linea, name, task, ul)
char *linea, *name;
int task, ul;
{
   FILE *fp;
   char filename[14];

   printf ("\nProcessing...");

   sprintf(filename, "LINE%d.BBS", ul);
   fp = fopen(filename, "at");

   fprintf(fp, "\n\n** MESSAGE **\n");
   fprintf(fp, "From: %s on line %d\n", name, task);
   fprintf(fp, "\n\"%s\"\n\n", linea);
   fprintf(fp, "\001");

   fclose(fp);

   printf("Sent\n\n");
}

