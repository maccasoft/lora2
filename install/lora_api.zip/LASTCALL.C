/*

                      LoraBBS (DOS / OS2) Ver. 2.33

    Copyright (c) 1989, 1990, 1991, 1992, 1993 by Marco Maccaferri.
                          All rights reserved.


                          Source code examples
                       Set/Read lastcaller record


  You may use this structures at your own risk. The author cannot guarantee
  that this structures are maintained in all future versions of the program.
  You can freely (and you are encouraged on that) distribute this file
  without limitations.

  You can contact the autor at one of the following address:

  Marco Maccaferri
  BBS: 39-51-6331730 (2:332/402)

*/
#include <stdio.h>
#include <io.h>
#include <time.h>
#include <fcntl.h>
#include <string.h>
#include <mem.h>
#include <sys/stat.h>

#include "lora.h"

void get_last_caller(task)
int task;
{
   int fd;
   struct _lastcall lastcall;

   fd = open("LASTCALL.BBS", O_RDONLY|O_BINARY|O_CREAT,S_IREAD|S_IWRITE);

   while (read(fd, (char *)&lastcall, sizeof(struct _lastcall)) == sizeof(struct _lastcall))
   {
      if (lastcall.line != task)
         strcpy(lastcall.name, "None");
   }

   close (fd);
}

void set_last_caller(usr, task, rate)
struct _usr *usr;
int task, rate;
{
   int fd;
   long tempo;
   struct tm *tim;
   struct _lastcall lc;

   fd = open("LASTCALL.BBS", O_APPEND|O_WRONLY|O_BINARY|O_CREAT,S_IREAD|S_IWRITE);

   memset((char *)&lc, 0, sizeof(struct _lastcall));

   lc.line = task;
   strcpy(lc.name, usr->name);
   strcpy(lc.city, usr->city);
   lc.baud = rate;
   lc.times = usr->times;
   strncpy(lc.logon, &usr->ldate[11], 5);
   tempo = time (NULL);
   tim = localtime (&tempo);
   sprintf(lc.logoff,"%2d:%02d",tim->tm_hour,tim->tm_min);

   write(fd, (char *)&lc, sizeof(struct _lastcall));

   close (fd);
}

